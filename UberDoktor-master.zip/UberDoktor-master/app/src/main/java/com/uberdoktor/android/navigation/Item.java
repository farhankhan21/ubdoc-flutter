package com.uberdoktor.android.navigation;


public class Item extends BaseItem {

    public Item(String name) {
        super(name);
    }
}
