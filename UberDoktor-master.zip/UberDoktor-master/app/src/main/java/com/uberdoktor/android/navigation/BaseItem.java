package com.uberdoktor.android.navigation;

public class BaseItem {
    private String mName;


    public BaseItem(String name) {
        mName = name;
    }

    public String getName() {
        return mName;
    }


}
